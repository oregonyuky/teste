package felipe.bcc.prova.db.util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import felipe.bcc.prova.db.DBCheques;

public class Conexao {
    private SQLiteDatabase database;
    private final DBCheques sqliteOpenHelper;

    public Conexao(Context context) {
        sqliteOpenHelper = new DBCheques(context);
    }

    public void conectar() throws SQLException {
        database = sqliteOpenHelper.getWritableDatabase();
    }

    public void desconectar() {
        sqliteOpenHelper.close();
    }

    public long inserir(String tabela, ContentValues dados) {
        return database.insert(tabela, null, dados);
    }

    public int apagar(String tabela, String restricao, String[] argumentos) {
        return database.delete(tabela, restricao, argumentos);
    }

    public Cursor consultar(String query, String[] argumentos) {
        return database.rawQuery(query, argumentos);
    }
}
