package felipe.bcc.prova.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBCheques extends SQLiteOpenHelper {
    private static final String NOME_BANCO = "cheques.db";
    private static final int VERSAO = 1;

    public DBCheques(Context context) {
        super(context, NOME_BANCO, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE cheque (" +
                "che_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "che_valor REAL NOT NULL, " +
                "che_vencimento TEXT NOT NULL, " +
                "che_dias INTEGER NOT NULL, " +
                "che_juros_mensais REAL NOT NULL, " +
                "che_valor_juros REAL NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // A primeira versão do banco ainda não possui migrações.
    }
}
