package felipe.bcc.prova.db.dal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import java.time.LocalDate;
import java.util.ArrayList;

import felipe.bcc.prova.db.bean.Cheque;
import felipe.bcc.prova.db.util.Conexao;

public class ChequeDAL {
    private static final String TABELA = "cheque";
    private final Conexao con;

    public ChequeDAL(Context context) {
        con = new Conexao(context);
        con.conectar();
    }

    public boolean salvar(Cheque cheque) {
        ContentValues dados = new ContentValues();
        dados.put("che_valor", cheque.getValor());
        dados.put("che_vencimento", cheque.getDataVencimento().toString());
        dados.put("che_dias", cheque.getDiasParaDeposito());
        dados.put("che_juros_mensais", cheque.getJurosMensais());
        dados.put("che_valor_juros", cheque.getValorJuros());

        long id = con.inserir(TABELA, dados);
        if (id > 0) {
            cheque.setId(id);
            return true;
        }
        return false;
    }

    public boolean apagar(long id) {
        return con.apagar(TABELA, "che_id = ?", new String[]{String.valueOf(id)}) > 0;
    }

    public ArrayList<Cheque> listar() {
        ArrayList<Cheque> cheques = new ArrayList<>();
        Cursor cursor = con.consultar("SELECT * FROM " + TABELA + " ORDER BY che_id", null);
        try {
            while (cursor.moveToNext()) {
                cheques.add(new Cheque(
                        cursor.getLong(cursor.getColumnIndexOrThrow("che_id")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("che_valor")),
                        LocalDate.parse(cursor.getString(cursor.getColumnIndexOrThrow("che_vencimento"))),
                        cursor.getInt(cursor.getColumnIndexOrThrow("che_dias")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("che_juros_mensais")),
                        cursor.getDouble(cursor.getColumnIndexOrThrow("che_valor_juros"))));
            }
        } finally {
            cursor.close();
        }
        return cheques;
    }

    public double calcularTotalLiquido() {
        Cursor cursor = con.consultar(
                "SELECT COALESCE(SUM(che_valor - che_valor_juros), 0) FROM " + TABELA, null);
        try {
            return cursor.moveToFirst() ? cursor.getDouble(0) : 0.0;
        } finally {
            cursor.close();
        }
    }

    public void fechar() {
        con.desconectar();
    }
}
