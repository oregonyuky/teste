package felipe.bcc.prova.db.bean;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Cheque {
    private long id;
    private final double valor;
    private final LocalDate dataVencimento;
    private final int diasParaDeposito;
    private final double jurosMensais;
    private final double valorJuros;

    public Cheque(long id, double valor, LocalDate dataVencimento, int diasParaDeposito,
                  double jurosMensais, double valorJuros) {
        this.id = id;
        this.valor = valor;
        this.dataVencimento = dataVencimento;
        this.diasParaDeposito = diasParaDeposito;
        this.jurosMensais = jurosMensais;
        this.valorJuros = valorJuros;
    }

    public Cheque(double valor, LocalDate dataVencimento, double jurosMensais,
                  LocalDate dataDeCalculo) {
        this(0, valor, dataVencimento,
                (int) ChronoUnit.DAYS.between(dataDeCalculo, dataVencimento),
                jurosMensais,
                calcularJuros(valor, jurosMensais,
                        (int) ChronoUnit.DAYS.between(dataDeCalculo, dataVencimento)));
    }

    public static double calcularJuros(double valor, double jurosMensais, int dias) {
        return valor * (((jurosMensais / 30.0) * dias) / 100.0);
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public double getValor() { return valor; }
    public LocalDate getDataVencimento() { return dataVencimento; }
    public int getDiasParaDeposito() { return diasParaDeposito; }
    public double getJurosMensais() { return jurosMensais; }
    public double getValorJuros() { return valorJuros; }
}
